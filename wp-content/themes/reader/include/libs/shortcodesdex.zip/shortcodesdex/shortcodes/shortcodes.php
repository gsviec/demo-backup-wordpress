<?php
/**
 * All Plugin Shortcodes
 */


/**
 * Columns
 */
 if( ! function_exists('column' ) ) :
function column( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'class' => '',
		'animation' => '',
		'grid' => '',
		'grid_tablet' => '',
		'offset' => '',
		'delay' => '',
    ), $atts));
	if($offset != ''){
	 $class .= ' col-md-offset-'.$offset;
	}
	if($animation!=''){
		$class .= ' animated ';
	}
	
	return '<div data-animation="'.$animation.'" class="col-md-'.esc_attr($grid).' col-sm-'.esc_attr($grid_tablet).' '.$class.'"  data-animation-delay="'.$delay.'">' . do_shortcode($content) . '</div>';
}
add_shortcode('column', 'column');
endif;

 if( ! function_exists('inner_column' ) ) :
function inner_column( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'class' => '',
		'grid' => '',
		'offset' => '',
		'animation' => '',
		'delay' => '',
    ), $atts));
	if($offset != ''){
	 $offset = 'col-md-offset-'.$offset;
	}
	if($animation!=''){
		$class .= ' animate '.$animation;
	}
	return '<div class="'.esc_attr($offset).' col-md-'.esc_attr($grid).' '.esc_attr($class).'" data-delay="'.esc_attr($delay).'">' . do_shortcode($content) . '</div>';
}
add_shortcode('inner_column', 'inner_column');
endif;

 if( ! function_exists('container' ) ) :
function container( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'class' => '',
		'animation' => '',
		'delay' => '',
    ), $atts));
	
	if($animation!=''){
		$class .= ' animate '.$animation;
	}
	return '<div class="container '.esc_attr($class).'" data-delay="'.esc_attr($delay).'">' . do_shortcode($content) . '</div>';
}
add_shortcode('container', 'container');
endif;

 if( ! function_exists('div' ) ) :
function div( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'class' => '',
		'animation' => '',
		'grid' => '',
		'grid_tablet' => '',
		'offset' => '',
		'delay' => '',
    ), $atts));
	if($offset != ''){
	 $offset = 'col-md-offset-'.$offset;
	}
	if($animation!=''){
		$class .= ' animated ';
	}
	
	return '<div data-animation="'.$animation.'" class="col-md-'.esc_attr($grid).' col-sm-'.esc_attr($grid_tablet).' '.$class.'"  data-animation-delay="'.$delay.'">' . do_shortcode($content) . '</div>';
}
add_shortcode('div', 'div');
endif;

 if( ! function_exists('featured_image' ) ) :
function featured_image( $atts, $content = null ) {
	extract(shortcode_atts(array(
		
    ), $atts));
	if(function_exists('r_option')){
		if(!r_option('auto_thumbnail')){	
		return get_the_post_thumbnail(get_the_id(),'blog-post-thumbnail');
		}
	}
}
add_shortcode('featured_image', 'featured_image');
endif;


 if( ! function_exists('video_iframe' ) ) :
function video_iframe( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'id_video'=>'',
    ), $atts));

	$output = '<div class="video-player"><iframe width="560" height="315" src="//www.youtube.com/embed/'.$id_video.'" allowfullscreen></iframe></div>';
	return $output;
}
add_shortcode('video_iframe', 'video_iframe');
endif;

 if( ! function_exists('audio_iframe' ) ) :
function audio_iframe( $atts, $content = null ) {
	extract(shortcode_atts(array(
		'url'=>'',
		'auto_play'=>'false'
    ), $atts));

	$output = '<div class="audio-player"><audio src="'.$url.'" width="100%" class="mejs-player" data-mejsoptions=\'{"alwaysShowControls": true}\'></audio></div>';
	return $output;
}
add_shortcode('audio_iframe', 'audio_iframe');
endif;


if( ! function_exists( 'row' ) ):
function row( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'class' => '',
		'animation' => '',
		'delay' => '',
	), $atts ) );
	if($animation!=''){
		$class .= ' animate '.$animation;
	}
	return '<div class="row '.esc_attr($class).'">' .  do_shortcode( $content )  . '</div>';
}
add_shortcode( 'row', 'row' );
endif;



/**
 * Buttons
 */
if( ! function_exists( 'button' ) ) :
function button( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'url'        => '',
		'target'     => '_self',
		'style'      => '',
		'color'      => 'darkblue',
		'size'       => '',
		'type'       => 'line',
		'icon'       => '',
		'icon_position' => 'after',
		'class' => ''
	), $atts ) );

	$button_icon = '';
	$class       .= " {$style}-btn";
	$class       .= " btn-{$color}";

	if( ! empty($icon) ) {
		if ( $icon_position == 'after' ) {			
			$button_content = do_shortcode($content);
			$button_content .= '<i class="'.$icon.'"></i>';
		} else {
			$button_content = '<i class="'.$icon.'"></i>';
			$button_content .= do_shortcode($content);
		}
		$class .= " icon-{$icon_position}";
	} else {
		$button_content = do_shortcode($content);
	}
	if($url==''){
		$url = '#';
	}
	       
	return '<a target="'.esc_attr($target).'" href="'.($url).'" class="btn '. $class .' '.$size.'">'. $button_content .'</a>';
}
add_shortcode( 'button', 'button' );
endif;



if( ! function_exists( 'twitter_feed' ) ):
function twitter_feed( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'username'        => '',
		'count'        => '',
	), $atts ) );
	
	$output = '<div class="twitter-feed">
		<div class="container">
			<div class="row">
				
				<i class="fa fa-3x fa-twitter"></i>
				<div class="tweet">
					                   
					<div class="tweets_feed" data-username="'.$username.'" data-count="'.$count.'" ></div>
				</div>
			</div>
		</div>
	</div>';
	return $output;
}
add_shortcode( 'twitter_feed', 'twitter_feed' );
endif;





if( ! function_exists( 'icon') ) :
/**
 * FontAwesome Icon shortcode.
 */
function icon( $atts, $content = null ) {
	extract( shortcode_atts( array(
		'icon'       => '',
		'url'        => '',
		'size'       => '',
		'new_window' => 'no'
	), $atts ) );

	$new_window = ( $new_window == "no") ? '_self' : '_blank';

	$output = '';
	$attrs = '';

	if( ! empty($url) ){
		$a_attrs = ' href="'. esc_url($url) .'" target="'. esc_attr($new_window) .'"';
	}

	if( !empty($size) ) {
		$attrs .= ' style="font-size:'. esc_attr($size) .';line-height:'. esc_attr($size) .'"';
	}

	if( $url != '' ){
		$output .= '<a class="" '. $a_attrs .'><i class="fa fa-'. $icon .'" style="font-size: '. $size .'; line-height: '. $size .';"></i></a>';
	}else{
		$output .= '<i class="fa fa-'. $icon .'" '. $attrs .'></i>';
	}
	$output = str_replace( array( '<p>' ), '', $output );
    $output = str_replace( array( '</p>' ), '', $output );
    $output = preg_replace("[\n|\r|\n\r]", '', $output);
  $output= trim ($output);
	return $output;
}
add_shortcode( 'icon', 'icon' );
endif;

if( ! function_exists( 'stag_map') ) :
/**
 * Google Map Shortcode
 *
 * @since 1.0.4
 */
function stag_map( $atts ) {
	extract( shortcode_atts( array(
		'lat'    => '37.42200',
		'long'   => '-122.08395',
		'width'  => '100%',
		'height' => '350px',
		'zoom'   => 15,
		'style'  => 'none'
	), $atts ) );

	$map_styles = array(
		'none'             => '[]',
		'mixed'            => '[{"featureType":"landscape","stylers":[{"hue":"#00dd00"}]},{"featureType":"road","stylers":[{"hue":"#dd0000"}]},{"featureType":"water","stylers":[{"hue":"#000040"}]},{"featureType":"poi.park","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","stylers":[{"hue":"#ffff00"}]},{"featureType":"road.local","stylers":[{"visibility":"off"}]}]',
		'pale_dawn'        => '[{"featureType":"landscape","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","stylers":[{"saturation":-100},{"lightness":51},{"visibility":"simplified"}]},{"featureType":"road.highway","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"road.arterial","stylers":[{"saturation":-100},{"lightness":30},{"visibility":"on"}]},{"featureType":"road.local","stylers":[{"saturation":-100},{"lightness":40},{"visibility":"on"}]},{"featureType":"transit","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"administrative.province","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":-25},{"saturation":-100}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]}]',
		'greyscale'        => '[{"featureType":"all","stylers":[{"saturation":-100},{"gamma":0.5}]}]',
		'bright_bubbly'    => '[{"featureType":"water","stylers":[{"color":"#19a0d8"}]},{"featureType":"administrative","elementType":"labels.text.stroke","stylers":[{"color":"#ffffff"},{"weight":6}]},{"featureType":"administrative","elementType":"labels.text.fill","stylers":[{"color":"#e85113"}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#efe9e4"},{"lightness":-40}]},{"featureType":"road.arterial","elementType":"geometry.stroke","stylers":[{"color":"#efe9e4"},{"lightness":-20}]},{"featureType":"road","elementType":"labels.text.stroke","stylers":[{"lightness":100}]},{"featureType":"road","elementType":"labels.text.fill","stylers":[{"lightness":-100}]},{"featureType":"road.highway","elementType":"labels.icon"},{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"landscape","stylers":[{"lightness":20},{"color":"#efe9e4"}]},{"featureType":"landscape.man_made","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels.text.stroke","stylers":[{"lightness":100}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"lightness":-100}]},{"featureType":"poi","elementType":"labels.text.fill","stylers":[{"hue":"#11ff00"}]},{"featureType":"poi","elementType":"labels.text.stroke","stylers":[{"lightness":100}]},{"featureType":"poi","elementType":"labels.icon","stylers":[{"hue":"#4cff00"},{"saturation":58}]},{"featureType":"poi","elementType":"geometry","stylers":[{"visibility":"on"},{"color":"#f0e4d3"}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#efe9e4"},{"lightness":-25}]},{"featureType":"road.arterial","elementType":"geometry.fill","stylers":[{"color":"#efe9e4"},{"lightness":-10}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"simplified"}]}]',
		'subtle_grayscale' => '[{"featureType":"landscape","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","stylers":[{"saturation":-100},{"lightness":51},{"visibility":"simplified"}]},{"featureType":"road.highway","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"road.arterial","stylers":[{"saturation":-100},{"lightness":30},{"visibility":"on"}]},{"featureType":"road.local","stylers":[{"saturation":-100},{"lightness":40},{"visibility":"on"}]},{"featureType":"transit","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"administrative.province","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"on"},{"lightness":-25},{"saturation":-100}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]}]'
	);

	$map_id = 'map'. rand(0, 99);

	wp_enqueue_script( 'google-maps', ( is_ssl() ? 'https' : 'http' ) . '://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false' );

	?>

	<script type="text/javascript">
	    jQuery(window).load(function(){
    	    var options = {
    	    	id: "<?php echo esc_attr($map_id); ?>",
    	    	styles: <?php echo esc_attr($map_styles[$style]); ?>,
    	    	zoom: <?php echo esc_attr($zoom); ?>,
    	    	center: {
    	    		lat: "<?php echo esc_attr($lat); ?>",
    	    		long: "<?php echo esc_attr($long); ?>"
    	    	}
    	    };
    	    Stagtools.Map.init(options);
	    });
	</script>

	<?php

	return "<div id='{$map_id}' class='google-map' style='width:{$width};height:{$height};'></div>";
}
add_shortcode( 'stag_map', 'stag_map' );
endif;

